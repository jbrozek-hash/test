import { getSession } from '@/lib/auth'
import getDb from '@/lib/db'
import { notFound } from 'next/navigation'
import KanbanBoard from '@/components/kanban/KanbanBoard'
import Link from 'next/link'
import { ArrowLeft, Settings } from 'lucide-react'

export default async function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return null

  const { id } = await params
  const db = getDb()

  const project = db.prepare(`
    SELECT p.* FROM projects p
    JOIN workspace_members wm ON wm.workspace_id = p.workspace_id
    WHERE p.id = ? AND wm.user_id = ?
  `).get(id, session.id) as any

  if (!project) notFound()

  const columns = db.prepare('SELECT * FROM columns WHERE project_id = ? ORDER BY col_order').all(id) as any[]
  const tasks = db.prepare(`
    SELECT t.*, u.name as assignee_name, u.image as assignee_image
    FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
    WHERE t.project_id = ? ORDER BY t.task_order
  `).all(id) as any[]
  const subtasks = db.prepare(`
    SELECT s.* FROM subtasks s JOIN tasks t ON t.id = s.task_id WHERE t.project_id = ?
  `).all(id) as any[]

  const members = db.prepare(`
    SELECT u.id, u.name, u.image FROM users u
    JOIN workspace_members wm ON wm.user_id = u.id
    WHERE wm.workspace_id = ?
  `).all(project.workspace_id) as any[]

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <div className="flex items-center gap-4 px-6 py-4 border-b bg-white">
        <Link href="/dashboard" className="text-gray-400 hover:text-gray-600 transition-colors">
          <ArrowLeft size={18} />
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-sm font-bold"
            style={{ backgroundColor: project.color }}>
            {project.name[0]}
          </div>
          <h1 className="text-lg font-semibold text-gray-900">{project.name}</h1>
          {project.description && <p className="text-sm text-gray-500">— {project.description}</p>}
        </div>
        <div className="ml-auto flex items-center gap-2 text-sm text-gray-500">
          <span>{tasks.length} zadań</span>
          <span>·</span>
          <span>{members.length} członków</span>
        </div>
      </div>

      {/* Board */}
      <div className="flex-1 overflow-hidden p-6">
        <KanbanBoard
          projectId={id}
          initialColumns={columns}
          initialTasks={tasks}
          initialSubtasks={subtasks}
          members={members}
        />
      </div>
    </div>
  )
}
