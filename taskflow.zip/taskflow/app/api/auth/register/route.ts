import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import getDb from '@/lib/db'
import { cuid, slugify } from '@/lib/utils'

export async function POST(req: NextRequest) {
  try {
    const { name, email, password, workspaceName } = await req.json()

    if (!name || !email || !password) {
      return NextResponse.json({ error: 'Uzupełnij wszystkie pola' }, { status: 400 })
    }

    const db = getDb()
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email)
    if (existing) {
      return NextResponse.json({ error: 'Email już istnieje' }, { status: 400 })
    }

    const hash = await bcrypt.hash(password, 10)
    const userId = cuid()

    db.prepare('INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)').run(userId, name, email, hash)

    // Create default workspace
    const wsName = workspaceName || `${name}'s Workspace`
    const wsId = cuid()
    let slug = slugify(wsName)
    const existing_slug = db.prepare('SELECT id FROM workspaces WHERE slug = ?').get(slug)
    if (existing_slug) slug = slug + '-' + Date.now()

    db.prepare('INSERT INTO workspaces (id, name, slug) VALUES (?, ?, ?)').run(wsId, wsName, slug)
    db.prepare('INSERT INTO workspace_members (id, workspace_id, user_id, role) VALUES (?, ?, ?, ?)').run(cuid(), wsId, userId, 'owner')

    // Create default channel
    const channelId = cuid()
    db.prepare('INSERT INTO channels (id, workspace_id, name, is_general) VALUES (?, ?, ?, 1)').run(channelId, wsId, 'general')

    // Create sample project with columns
    const projectId = cuid()
    db.prepare('INSERT INTO projects (id, workspace_id, name, description, color) VALUES (?, ?, ?, ?, ?)').run(
      projectId, wsId, 'Pierwszy Projekt', 'Mój pierwszy projekt', '#6366f1'
    )
    const cols = [
      { name: 'Do zrobienia', color: '#e5e7eb' },
      { name: 'W toku', color: '#fef3c7' },
      { name: 'Przegląd', color: '#dbeafe' },
      { name: 'Zrobione', color: '#dcfce7' },
    ]
    cols.forEach((col, i) => {
      db.prepare('INSERT INTO columns (id, project_id, name, col_order, color) VALUES (?, ?, ?, ?, ?)').run(
        cuid(), projectId, col.name, i, col.color
      )
    })

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Błąd serwera' }, { status: 500 })
  }
}
