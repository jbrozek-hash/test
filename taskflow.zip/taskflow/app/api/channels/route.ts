import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import getDb from '@/lib/db'
import { cuid } from '@/lib/utils'

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const workspaceId = req.nextUrl.searchParams.get('workspaceId')
  if (!workspaceId) return NextResponse.json({ error: 'workspaceId required' }, { status: 400 })

  const db = getDb()
  const channels = db.prepare('SELECT * FROM channels WHERE workspace_id = ? ORDER BY is_general DESC, name').all(workspaceId)
  return NextResponse.json(channels)
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { workspaceId, name } = await req.json()
  if (!workspaceId || !name) return NextResponse.json({ error: 'Wymagane pola' }, { status: 400 })

  const db = getDb()
  const id = cuid()
  db.prepare('INSERT INTO channels (id, workspace_id, name) VALUES (?, ?, ?)').run(id, workspaceId, name.toLowerCase().replace(/\s+/g, '-'))

  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(id)
  return NextResponse.json(channel, { status: 201 })
}
