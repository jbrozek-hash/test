import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import getDb from '@/lib/db'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const db = getDb()

  const project = db.prepare(`
    SELECT p.* FROM projects p
    JOIN workspace_members wm ON wm.workspace_id = p.workspace_id
    WHERE p.id = ? AND wm.user_id = ?
  `).get(id, session.id) as any

  if (!project) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const columns = db.prepare('SELECT * FROM columns WHERE project_id = ? ORDER BY col_order').all(id) as any[]

  const tasks = db.prepare(`
    SELECT t.*, u.name as assignee_name, u.image as assignee_image
    FROM tasks t
    LEFT JOIN users u ON u.id = t.assignee_id
    WHERE t.project_id = ?
    ORDER BY t.task_order
  `).all(id) as any[]

  const subtasks = db.prepare(`
    SELECT s.* FROM subtasks s
    JOIN tasks t ON t.id = s.task_id
    WHERE t.project_id = ?
    ORDER BY s.sub_order
  `).all(id) as any[]

  return NextResponse.json({ project, columns, tasks, subtasks })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const db = getDb()
  db.prepare('UPDATE projects SET status = ? WHERE id = ?').run('archived', id)
  return NextResponse.json({ success: true })
}
