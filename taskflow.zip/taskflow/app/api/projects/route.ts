import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import getDb from '@/lib/db'
import { cuid } from '@/lib/utils'

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const workspaceId = req.nextUrl.searchParams.get('workspaceId')
  if (!workspaceId) return NextResponse.json({ error: 'workspaceId required' }, { status: 400 })

  const db = getDb()
  const projects = db.prepare(`
    SELECT p.* FROM projects p
    JOIN workspace_members wm ON wm.workspace_id = p.workspace_id
    WHERE p.workspace_id = ? AND wm.user_id = ? AND p.status = 'active'
    ORDER BY p.created_at
  `).all(workspaceId, session.id)

  return NextResponse.json(projects)
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { workspaceId, name, description, color } = await req.json()
  if (!workspaceId || !name) return NextResponse.json({ error: 'Wymagane pola' }, { status: 400 })

  const db = getDb()
  const member = db.prepare('SELECT id FROM workspace_members WHERE workspace_id = ? AND user_id = ?').get(workspaceId, session.id)
  if (!member) return NextResponse.json({ error: 'Brak dostępu' }, { status: 403 })

  const projectId = cuid()
  db.prepare('INSERT INTO projects (id, workspace_id, name, description, color) VALUES (?, ?, ?, ?, ?)').run(
    projectId, workspaceId, name, description || null, color || '#6366f1'
  )

  const cols = ['Do zrobienia', 'W toku', 'Przegląd', 'Zrobione']
  const colColors = ['#e5e7eb', '#fef3c7', '#dbeafe', '#dcfce7']
  cols.forEach((name, i) => {
    db.prepare('INSERT INTO columns (id, project_id, name, col_order, color) VALUES (?, ?, ?, ?, ?)').run(
      cuid(), projectId, name, i, colColors[i]
    )
  })

  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId)
  return NextResponse.json(project, { status: 201 })
}
