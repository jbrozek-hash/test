import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import getDb from '@/lib/db'
import { cuid } from '@/lib/utils'

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const body = await req.json()
  const db = getDb()

  const allowed = ['title', 'description', 'priority', 'column_id', 'assignee_id', 'due_date', 'task_order']
  const sets: string[] = []
  const vals: any[] = []

  for (const key of allowed) {
    if (key in body) {
      sets.push(`${key} = ?`)
      vals.push(body[key])
    }
  }
  if (sets.length === 0) return NextResponse.json({ error: 'No fields' }, { status: 400 })

  sets.push(`updated_at = datetime('now')`)
  vals.push(id)

  db.prepare(`UPDATE tasks SET ${sets.join(', ')} WHERE id = ?`).run(...vals)
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id)
  return NextResponse.json(task)
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  getDb().prepare('DELETE FROM tasks WHERE id = ?').run(id)
  return NextResponse.json({ success: true })
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const db = getDb()

  const task = db.prepare(`
    SELECT t.*, u.name as assignee_name, c.name as creator_name
    FROM tasks t
    LEFT JOIN users u ON u.id = t.assignee_id
    LEFT JOIN users c ON c.id = t.creator_id
    WHERE t.id = ?
  `).get(id) as any

  if (!task) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const subtasks = db.prepare('SELECT * FROM subtasks WHERE task_id = ? ORDER BY sub_order').all(id)
  const comments = db.prepare(`
    SELECT cm.*, u.name as author_name, u.image as author_image
    FROM comments cm JOIN users u ON u.id = cm.author_id
    WHERE cm.task_id = ? ORDER BY cm.created_at
  `).all(id)

  return NextResponse.json({ task, subtasks, comments })
}
