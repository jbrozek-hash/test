import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import getDb from '@/lib/db'
import { cuid } from '@/lib/utils'

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const { title } = await req.json()
  if (!title?.trim()) return NextResponse.json({ error: 'Tytuł wymagany' }, { status: 400 })

  const db = getDb()
  const maxOrder = (db.prepare('SELECT MAX(sub_order) as m FROM subtasks WHERE task_id = ?').get(id) as any)?.m ?? -1
  const subId = cuid()
  db.prepare('INSERT INTO subtasks (id, task_id, title, sub_order) VALUES (?, ?, ?, ?)').run(subId, id, title.trim(), maxOrder + 1)

  const sub = db.prepare('SELECT * FROM subtasks WHERE id = ?').get(subId)
  return NextResponse.json(sub, { status: 201 })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { subtaskId, done } = await req.json()
  getDb().prepare('UPDATE subtasks SET done = ? WHERE id = ?').run(done ? 1 : 0, subtaskId)
  return NextResponse.json({ success: true })
}
