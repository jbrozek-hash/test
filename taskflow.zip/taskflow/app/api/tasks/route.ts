import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import getDb from '@/lib/db'
import { cuid } from '@/lib/utils'

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { projectId, columnId, title, description, priority, assigneeId, dueDate } = await req.json()
  if (!projectId || !columnId || !title) return NextResponse.json({ error: 'Wymagane pola' }, { status: 400 })

  const db = getDb()
  const maxOrder = (db.prepare('SELECT MAX(task_order) as m FROM tasks WHERE column_id = ?').get(columnId) as any)?.m ?? -1

  const taskId = cuid()
  db.prepare(`
    INSERT INTO tasks (id, project_id, column_id, creator_id, assignee_id, title, description, priority, due_date, task_order)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(taskId, projectId, columnId, session.id, assigneeId || null, title, description || null, priority || 'medium', dueDate || null, maxOrder + 1)

  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId)
  return NextResponse.json(task, { status: 201 })
}
